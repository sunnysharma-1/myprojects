package com.example.health_and_doctor_appointment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
