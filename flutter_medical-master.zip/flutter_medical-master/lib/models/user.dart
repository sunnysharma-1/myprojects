class CurrentUser {
  String userId;
  CurrentUser({this.userId});
}
