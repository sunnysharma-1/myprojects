class UserProfile {
  static String userImagePath = "";
  static String userFirstName = "";
  static String userLastName = "";
  static String userEmail = "";
  static double userHealthScore = 0;
  static String userWeight = "";
  static String userHeight = "";
  static String userAge = "";
  static String userAddress = "";
  static String userBMI = "";
  static String userLanguage = "";
  static String userPhone = "";
  static String userGender = "";
  static String userDOB = "";
}
